import pyautogui as spam
import time
from lib2to3.pygram import Symbols

limite_msg = 500 #<--- coloque a quantidade de mensagens q vai ser enviada 
msg = 'gabriel, o grande, o incrivel, o extraordinario, o magnifico, CU DE AMOLAR FACÃO'





i = 0
time.sleep(4)

while i < int(limite_msg):
    spam.press("Enter")
    spam.typewrite(msg)
    i += 1