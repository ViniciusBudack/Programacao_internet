import pyautogui as spam
import time
from lib2to3.pygram import Symbols

limite_msg = 1000 #<--- coloque a quantidade de mensagens q vai ser enviada 
msg = 'eu.... sou.... o homem de ferro'#<--- coloque a mensagem q sera enviada 

i = 0
time.sleep(4)

while i < int(limite_msg):
    spam.press("Enter")
    spam.typewrite(msg)
    i += 1